.oO VideoPaper V1.04a / 29.11.15 Oo.

Current issues:
- on looping it still might blink black / red for a millisecond
- Video scaling, probably can't be solved. You need videos in the correct resolution(s) of your screen.
  You can test this by playing a file in windows media player and going fullscreen. Are there black bars? If yes, then VideoPaper will have them too.
  

Changelog:
- improved looping
- added multi screen / panel support
- fixed user switching
- fixed return from hybernation, suspend etc.
- fixed shutdown (no longer blocks shutdown)
- new gui
- added notifications (can be disabled)
- general code cleanup


Getting it working:
1. You need Windows 10. I have tested it with threshold 2. 64bit.
2. Set your desktop wallpaper to slideshow, you can point it at one image but it has to be in slideshow mode. Change delay to 1 day.
3. Run the file, set a video.
4. ???
5. Profit!


-Ize